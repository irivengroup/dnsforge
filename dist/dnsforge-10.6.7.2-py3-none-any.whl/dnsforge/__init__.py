from __future__ import annotations

__version__ = "10.6.7.2"
