"""Initialize domain model."""
