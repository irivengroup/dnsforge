"""Initialize infrastructure adapters."""
